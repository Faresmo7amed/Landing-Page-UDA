// the main variables
var navList = document.getElementById('navbar__list');
var pageSections  = document.querySelectorAll('section');



// to create li and a tags by js file into ul in html file 
var newList = () => { let nu = '';
pageSections.forEach(x => {
        var href = x.id;
        var secDat = x.dataset.nav;
        nu += `<li><a class="menu__link" href="#${href}">${secDat}</a></li>`;
    }); navList.innerHTML = nu;
};
newList();



// to add active class to the active section
var i = 0
for (;i < pageSections.length;) {
    var section = pageSections[i];
    section.classList.add('your-active-class');
    i++
}


// to remove active class from the unactive section
var i = 0
for (;i < pageSections.length;) {
    var section = pageSections[i];
    section.classList.remove('your-active-class');
    i++
}



// knowledge DOMRect from page on scroll and Executing the Add Class Active command and removing it from all 
var Bounding = (x) => {
    return Math.trunc(x.getBoundingClientRect().top);};
var conditionClass = () => {
    pageSections.forEach(x => {
            var sec = Bounding(x)
        if(sec < 150 && sec >= -150){
            x.classList.add('your-active-class')
        }else{
            x.classList.remove('your-active-class')
        };
    });
}; window.addEventListener('scroll', conditionClass );


// to make a smooth scroll
var tagA = document.querySelectorAll(' nav a');
tagA.forEach(x => {
    x.addEventListener('click', function(x) {
        x.preventDefault();
        var a = x.target.attributes.href.value;
        var sec = document.querySelector(a);
        sec.scrollIntoView({ behavior : 'smooth' });
    });  
});






